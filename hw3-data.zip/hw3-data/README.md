# HW03 Data Files

Transit database CSV files for Problem 1.

**data/** - lines, stops, line_stops, trips, stop_events

See assignment for requirements.
